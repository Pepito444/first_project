//
//  verificationScreen.swift
//  AdaProject
//
//  Created by user198010 on 7/24/21.
//

import Foundation
